<?php



// Menambahkan tag judul Halaman dgn fungsi bawaan WP:
// Pengaturan -> General Settings
add_theme_support( 'title-tag' );


function load_stylesheets(){

    $loops_styles =['bootstrap', 'main_style', 'fonts','perfect-scrollbar','custome','dvd_dchat','g_maps'];

    // var_dump($loops_styles);

    // Looping untuk setiap file css yg dibutuhkan
    foreach($loops_styles as $style){
        // var_dump($style);
        wp_register_style($style,get_template_directory_uri()."/assets/css/$style.css", array(), false, 'all');
        wp_enqueue_style($style);

    }

}

// load_stylesheets();

add_action('wp_enqueue_scripts','load_stylesheets');


function load_js(){

    wp_deregister_script('jquery');
    $loops_scripts =['core', 'script', 'perfect-scrollbar.jquery','menu_handle', 'dvd_dchat_popUp'];

    // Looping untuk setiap file css yg dibutuhkan
    foreach($loops_scripts as $script){
        // var_dump($style);
        wp_register_script($script,get_template_directory_uri()."/assets/js/$script.js", '', 1, true);
        wp_enqueue_script($script);

    }
}
add_action('wp_enqueue_scripts','load_js');



add_theme_support('menus');

register_nav_menus(

array(
    'top-menu'=>__('Top Menu','theme'),
    'footer-menu'=>__('Footer Menu','theme')
)

);