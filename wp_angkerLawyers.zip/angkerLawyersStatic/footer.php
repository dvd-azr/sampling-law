
        <!-- Hubungi Kami...-->
        <section id="contact_footer" class="bg-accent-2">
            <section class="section parallax-container" data-parallax-img="<?=get_template_directory_uri()?>/assets/images/bg-image-2.jpg">
                <div style="background: linear-gradient(to right, #181d26, transparent, #181d26); "
                    class="parallax-content parallax-light">
                    <div class="section-lg">
                        <div class="container">
                            <div class="row row-50 justify-content-md-center justify-content-xl-between">
                                <div class="col-md-10 col-lg-6 col-xl-5 mt-0">
                                    <h3 class="heading-decorated mt-0" style="max-width: 70%;">Alamat Kami</h3>

                                    <!-- Unordered list-->
                                    <section class="section-sm pb-4 pt-4">
                                        <div class="post-classic-title-icon linear-icon-map-marker">
                                            <h5>Kantor</h5>
                                        </div>
                                        <ul class="light list-ordered">
                                            <li>Jl. Selorejo, Perumahan Griya Setaman Kav. F, Kota Malang, Jawa
                                                Timur.
                                            </li>
                                            <li> Jl. Eastwood EW 6, No. 66, Citraland, Kota Surabaya, Jawa Timur.
                                            </li>
                                            <li>Jl. Mayor Abdullah, Kota Tual, Maluku Tenggara.</li>
                                        </ul>



                                    </section>

                                    <div class="group mt-0 pages">
                                        <div class="icon-list-wrap icon icon-white linear-icon-telephone">
                                            <a href="standard-post.html">
                                                081333936989 | 082238793851</a>
                                        </div>

                                        <div class="icon-list-wrap icon icon-white linear-icon-envelope">
                                            <a href="standard-post.html">angkerlawyers@gmail.com</a>
                                        </div>

                                    </div>

                                </div>
                                <div class="col-md-10 col-lg-6">
                                    <!-- Video overlay wrap-->
                                    <div class="video-overlay-wrap">

                                        <div class="map_info_wrap">

                                            <div class="map_info_card">

                                                <div class="info_place_desc">
                                                    <div class="info_name">
                                                        ANGKER LAWYERS
                                                        <small>Advokat & Konsultan Hukum</small>
                                                    </div>
                                                    <div class="info_addres">Jl. Selorejo, Perumahan Griya Setaman Kav.
                                                        F, Kota Malang, Jawa
                                                        Timur.</div>

                                                </div>

                                                <div class="info_navigate">
                                                    <a target="_blank" jstcache="52"
                                                        href="https://maps.google.com/maps?ll=-7.955486,112.635767&amp;z=13&amp;t=m&amp;hl=en-US&amp;gl=US&amp;mapclient=embed&amp;daddr=Jl.%20Selorejo%20Kota%20Malang%20Jawa%20Timur%2065141@-7.955485899999999,112.6357668"
                                                        class="navigate-link">
                                                        <div class="info_navigate_icon map_info_icon"></div>
                                                        <div jstcache="53" class="info_navigate_text">Directions</div>
                                                    </a>


                                                    <!-- <div class="info_tooltip_anchor">
                                                        <div class="info_tooltip_tip_outer"></div>
                                                        <div class="info_tooltip_tip_inner"></div>
                                                        <div class="info_tooltip_content">
                                                            <div jstcache="54">Get directions to this location on Google
                                                                Maps.</div>
                                                        </div>
                                                    </div> -->
                                                </div>

                                                <div jstcache="41" class="review-box">
                                                    <div jstcache="42" class="review-number" jsan="7.review-number">5.0
                                                    </div>
                                                    <div jstcache="43" jsinstance="0"
                                                        class="map_info_icon rating-star rating-full-star"
                                                        jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                    <div jstcache="43" jsinstance="1"
                                                        class="map_info_icon rating-star rating-full-star"
                                                        jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                    <div jstcache="43" jsinstance="2"
                                                        class="map_info_icon rating-star rating-full-star"
                                                        jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                    <div jstcache="43" jsinstance="3"
                                                        class="map_info_icon rating-star rating-full-star"
                                                        jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                    <div jstcache="43" jsinstance="*4"
                                                        class="map_info_icon rating-star rating-full-star"
                                                        jsan="7.icon,7.rating-star,7.rating-full-star"></div> <a
                                                        target="_blank" jstcache="44"
                                                        href="https://www.google.com/search?safe=strict&ei=aT3tXbCZCM7gz7sPuJGe8AQ&q=Pengacara+di+malang+%7C+Angker+Lawyer%2C+jalan+Selorejo+Perumahan+Griya+Setaman+Kav+F+Kota+Malang+Jawa+Timur&oq=Pengacara+di+malang+%7C+Angker+Lawyer%2C+jalan+Selorejo+Perumahan+Griya+Setaman+Kav+F+Kota+Malang+Jawa+Timur&gs_l=psy-ab.3...14742.91164..93371...0.0..0.0.0.......26....1j2..gws-wiz.tlVrfl9tF-o&ved=0ahUKEwjw8bXy06bmAhVO8HMBHbiIB04Q4dUDCAs&uact=5"
                                                        jsaction="mouseup:placeCard.reviews" class="review-box-link"
                                                        jsan="7.review-box-link,8.href,0.target,22.jsaction">17
                                                        reviews</a>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="video-overlay__video">
                                            <div class="entry-video embed-responsive embed-responsive-16by9">
                                                <iframe width="886" height="320" id="gmap_canvas"
                                                    src="https://maps.google.com/maps?q=Jalan%20Selorejo%2C%20Kota%20Malang%2C%20Jawa%20Timur&t=&z=19&ie=UTF8&iwloc=&output=embed"
                                                    frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
                                                </iframe>
                                                <!-- <iframe width="886" height="668"
                                                    src="//www.youtube.com/embed/ccuQoF0vKYU"
                                                    allowfullscreen=""></iframe> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </section>




        <!-- Footer -->

        <footer class="footer-corporate bg-secondary-1">
            <div class="container">

                <div class="footer-corporate__inner justify-content-center">
                    <a class="brand" href="index.html">
                        <img src="<?=get_template_directory_uri()?>/assets/images/logo/logo-180x180.png" alt=""
                            style="width: 50px !important; height: auto !important;" width="191" height="51" />
                    </a>
                    <p class="rights">
                        <span>Angker Lawyers</span>
                        <span>&copy;&nbsp;</span>
                        <span class="copyright-year"></span>
                        <!-- <span>.&nbsp;All rights reserved.</span> -->
                    </p>

                </div>
            </div>
        </footer>





 </div>
 <!-- end page class -->


 <div id="page-loader">
        <div class="cssload-container">
            <div class="cssload-speeding-wheel"></div>
        </div>
    </div>
    <!-- Panel Thumbnail-->






    <!-- ============================================================ -->
    <!-- Btn chat Triger -->
    <div class="dchat_btn__wrapper init">
        <div class="wrapper__circle">

            <div class="dchat_icon">

                <svg focusable="false" aria-hidden="true" viewBox="0 0 28 32">
                    <path
                        d="M28,32 C28,32 23.2863266,30.1450667 19.4727818,28.6592 L3.43749107,28.6592 C1.53921989,28.6592 0,27.0272 0,25.0144 L0,3.6448 C0,1.632 1.53921989,0 3.43749107,0 L24.5615088,0 C26.45978,0 27.9989999,1.632 27.9989999,3.6448 L27.9989999,22.0490667 L28,22.0490667 L28,32 Z M23.8614088,20.0181333 C23.5309223,19.6105242 22.9540812,19.5633836 22.5692242,19.9125333 C22.5392199,19.9392 19.5537934,22.5941333 13.9989999,22.5941333 C8.51321617,22.5941333 5.48178311,19.9584 5.4277754,19.9104 C5.04295119,19.5629428 4.46760991,19.6105095 4.13759108,20.0170667 C3.97913051,20.2124916 3.9004494,20.4673395 3.91904357,20.7249415 C3.93763774,20.9825435 4.05196575,21.2215447 4.23660523,21.3888 C4.37862552,21.5168 7.77411059,24.5386667 13.9989999,24.5386667 C20.2248893,24.5386667 23.6203743,21.5168 23.7623946,21.3888 C23.9467342,21.2215726 24.0608642,20.9827905 24.0794539,20.7254507 C24.0980436,20.4681109 24.0195551,20.2135019 23.8614088,20.0181333 Z">
                    </path>
                </svg>
            </div>


            <div class="dchat_close">
                <svg class="svgIcon" focusable="false" height="16px" width="16px" version="1.1" viewBox="0 0 16 16"
                    x="0px" y="0px">
                    <g fill="#ffff" fill-rule="evenodd" stroke="none" stroke-width="1">
                        <g transform="translate(-712.000000, -1096.000000)">
                            <g stroke="#ffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                                transform="translate(709.000000, 320.000000)">
                                <path d="M5.833,778.833 L16.167,789.167"></path>
                                <path d="M16.167,778.833 L5.833,789.167"></path>
                            </g>
                        </g>
                    </g>
                </svg>
            </div>
        </div>
    </div>

    <!-- ============================================================ -->

    <!-- Chat -->

    <div class="main_dchat_wrapper">
        <div class="main_dchat_body">

            <div class="dchat_header">
                <div class="user_content">
                    <img src="<?=get_template_directory_uri()?>/assets/images/logo/logo-270x270-mirror.png" alt="" class="img-thumbnail">

                    <div class="details">
                        <div class="btn__details">
                            <a href="#" class="R_btn">
                                <i class="fa fa-minus"></i>
                            </a>


                        </div>

                        <h5>ANGKER LAWYERS</h5>
                        <p>Advokat & Konsultan Hukum</p>
                    </div>
                </div>

            </div>

            <div class="dchat_messages_box">

                <!-- <div class="message">
                    <div class="message-content">
                        <span class="img-thumbnail-variant-1" href="./assets/images/WA_qr_code/qr_WA-700px.png"
                            data-lightgallery="item">
                            <figure>
                                <img src="./assets/images/WA_qr_code/qr_WA-700px.png" alt="" width="886" height="668" />
                            </figure>

                        </span>

                        Silahkan click & scan QR code diatas agar terhubung langsung dengan kami melalui
                        WhatsAPP (WA) di handphone Anda.

                    </div>
                </div> -->

                <!-- <a class="img-thumbnail-variant-1" href="./assets/images/WA_qr_code/qr_WA-700px.png"
                    data-lightgallery="item">
                    <figure>
                        <img src="./assets/images/WA_qr_code/qr_WA-700px.png" alt="" width="886" height="668" />
                    </figure>

                </a> -->
            </div>



            <div class="dchat__controls">

                <div class="input-group">
                    <input class="form-control" id="pesan" placeholder="Type your message here..." type="text">

                    <div class="input-group-append">
                        <a class="input-group-text">
                            <i class="fa fa-paper-plane"></i>
                        </a>
                    </div>

                </div>

                <div class="dchat_btn_extra">
                    <div class="R_btn_extra">
                        <a href="#">
                            <i class="fa fa-picture-o"></i>
                        </a>
                        <a href="#">
                            <i class=" fa fas fa-film"></i>
                        </a>
                        <a href="#">
                            <i class=" fa fa-paperclip"></i>
                        </a>

                        <a href="#">
                            <i class="fa fa-smile-o"></i>
                        </a>
                    </div>
                    <!-- <div class="L_btn_extra">
                        <a href="#">
                            <span class="smile">🤓</span>
                        </a>
                        <a href="#">
                            <span class="smile">👌</span>
                        </a>


                    </div> -->
                </div>

            </div>
        </div>


    </div>








<?php wp_footer(); ?>
</body>
</html>