<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>


    <link rel="icon" href="<?=get_template_directory_uri()?>/assets/images/logo/logo-32x32.png" sizes="32x32" type="image/x-icon">

    <link id="tmplt_dir" rel="stylesheet" href="<?=get_template_directory_uri()?>">
</head>

<!-- <body  <?php body_class(); ?> > -->
<body >

 <!-- Page-->
 <div class="page">
     <!-- Page header-->
        <header class="page-header">
            <!-- RD Navbar-->
            <div class="rd-navbar-wrap">
                <nav class="rd-navbar rd-navbar_modern" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed"
                    data-sm-device-layout="rd-navbar-fixed" data-md-layout="rd-navbar-static"
                    data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static"
                    data-lg-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static"
                    data-xl-layout="rd-navbar-static" data-xxl-device-layout="rd-navbar-static"
                    data-xxl-layout="rd-navbar-static" data-stick-up-clone="false" data-sm-stick-up="true"
                    data-md-stick-up="true" data-lg-stick-up="true" data-md-stick-up-offset="50px"
                    data-lg-stick-up-offset="50px">
                    <!-- RD Navbar Top Panel-->
                    <div class="rd-navbar-top-panel rd-navbar-search-wrap">
                        <div class="rd-navbar-top-panel__main">
                            <div class="rd-navbar-top-panel__toggle rd-navbar-fixed__element-1 rd-navbar-static--hidden"
                                data-rd-navbar-toggle=".rd-navbar-top-panel__main"><span></span></div>
                            <div class="rd-navbar-top-panel__content">
                                <div class="rd-navbar-top-panel__left">
                                    <ul class="list-inline-xxs">
                                        <li>
                                            <a class="icon icon-xxs icon-primary linear-icon-map-marker" href="#"></a>
                                        </li>
                                        <li style="font-size: 14px; color: #cca776; padding-left:0"> Malang, Jawa Timur,
                                            Indonesia</li>

                                    </ul>
                                </div>
                                <div class="rd-navbar-top-panel__right">
                                    <ul class="rd-navbar-items-list">
                                        <li>
                                            <div class="unit flex-row align-items-center unit-spacing-xs">
                                                <div class="unit__left"><span
                                                        class="icon icon-xxs icon-primary linear-icon-telephone"></span>
                                                </div>
                                                <div class="unit__body">
                                                    <ul class="list-pipe">
                                                        <li><a href="callto:#">081333936989 </a></li>
                                                        <li><a href="callto:#">082238793851</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="unit flex-row align-items-center unit-spacing-xs">
                                                <div class="unit__left"><span
                                                        class="icon icon-xxs icon-primary linear-icon-envelope"></span>
                                                </div>
                                                <div class="unit__body">
                                                    <a>angkerlawyers@gmail.com</a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Pannel Cari -->
                        <!-- <div class="rd-navbar-top-panel__aside">
                            <ul class="rd-navbar-items-list">
                                <li>
                                    <div class="rd-navbar-fixed__element-2">
                                        <button class="rd-navbar-search__toggle rd-navbar-search__toggle_additional"
                                            data-rd-navbar-toggle=".rd-navbar-search-wrap"></button>
                                    </div>
                                </li>
                            </ul>
                        </div> -->


                        <!-- RD Search-->
                        <!-- <div class="rd-navbar-search rd-navbar-search_toggled rd-navbar-search_not-collapsable">
                            <form class="rd-search" action="#" data-search-live="rd-search-results-live">
                                <div class="form-wrap">
                                    <input class="form-input" id="rd-navbar-search-form-input" type="text" name="s"
                                        autocomplete="off">
                                    <label class="form-label" for="rd-navbar-search-form-input">Kata Kunci</label>
                                    <div class="rd-search-results-live" id="rd-search-results-live"></div>
                                </div>
                                <button class="rd-search__submit" type="submit"></button>
                            </form>
                            <div class="rd-navbar-fixed--hidden">
                                <button class="rd-navbar-search__toggle" data-custom-toggle=".rd-navbar-search-wrap"
                                    data-custom-toggle-disable-on-blur="true"></button>
                            </div>
                        </div> -->
                        
                        <!-- End Pannel Cari -->



                    </div>
                    <div class="rd-navbar-inner">
                        <!-- RD Navbar Panel-->
                        <div class="rd-navbar-panel">
                            <button class="rd-navbar-toggle"
                                data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                            <!-- RD Navbar Brand-->
                            <div class="rd-navbar-brand">
                                <a class="brand-name" href="#">
                                    <!-- <img src="images/logo/logo-960-5.png" alt="" width="191" height="51"/> -->
                                    <img src="<?=get_template_directory_uri()?>/assets/images/logo/logo-960-5.png" alt="" />
                                </a>
                            </div>
                        </div>
                        <!-- RD Navbar Nav -->
                        <!-- Menu Utama -->
                        <div class="rd-navbar-nav-wrap">
                            <ul class="rd-navbar-nav">

							
                                <li class="active"><a href="index-2.html">Beranda</a></li>
                                <li><a href="tentang.html">Tentang Kami</a></li>
                                <li><a href="praktik.html">Ruang Lingkup</a></li>
                                <li><a href="layanan.html">Layanan</a></li>
                                <li><a href="contacts.html">Kontak</a>
                                </li>
							</ul>
							<?php 
							// wp_nav_menu(
							// 	array(
							// 		'theme_location'=>'top-menu',
							// 		'menu_class' =>'rd-navbar-nav'

							// 	)
							// 	);
							?>
                        </div>
                    </div>
                </nav>
            </div>
        </header>

