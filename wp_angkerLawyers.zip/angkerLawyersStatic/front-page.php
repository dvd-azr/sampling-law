<?php get_header() ?>


<?php 
// var_dump(get_template_directory_uri())

?>





        <section id="all">

            <section id="beranda" class="wrapper__page selected">

            
                    <!-- Swiper-->
                    <section>
                        <div class="swiper-container swiper-slider swiper-slider_fullheight swiper-slider_nav-responsive"
                            data-simulate-touch="false" data-loop="true" data-autoplay="5500">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide bg-accent-2" data-slide-bg="<?= bloginfo('template_directory')?>/assets/images/sliders/1.jpg">

                                </div>
                                <div class="swiper-slide bg-accent-2"
                                    data-slide-bg="<?= bloginfo('template_directory')?>/assets/images/slider-1-slide-2-1920x980.jpg">

                                </div>
                                <div class="swiper-slide bg-accent-2"
                                    data-slide-bg="<?= bloginfo('template_directory')?>/assets/images/slider-1-slide-3-1920x980.jpg">

                                </div>
                            </div>
                            <!-- Swiper Pagination-->
                            <div class="swiper-pagination"></div>
                            <!-- Swiper Navigation-->
                            <div class="swiper-button-prev linear-icon-chevron-left"></div>
                            <div class="swiper-button-next linear-icon-chevron-right"></div>
                        </div>
                    </section>

                    <!-- Info-->
                    <section class="section-lg bg-default">
                        <div class="container">
                            <!-- Profile Corporate-->
                            <article class="profile-corporate">
                                <img class="profile-corporate__image" style="width: 270px !important"
                                    src="<?= bloginfo('template_directory')?>/assets/images/logo/logo-270x270-mirror.png" alt="" />
                                <h2 class="heading-decorated heading-decorated_center profile-corporate__title">ANGKER
                                    LAWYERS
                                </h2>
                                <div class="slick-line" style="margin-bottom: 10px;  width: 50%;"></div>
                                <h4 class="profile-corporate__subtitle">Advokat dan Konsultan Hukum
                                </h4>
                                <div class="profile-corporate__caption">
                                    <h6 class="first-letter">Kantor Hukum “ANGKER LAWYERS”
                                        merupakan firma hukum yang terdiri dari para praktisi hukum,
                                        Advokat dan Konsultan Hukum yang tergabung dalam PERADI (Perhimpunan Advokat
                                        Indonesia)
                                        dengan kredibilitas / pengalaman mempuni
                                        dalam bidang penanganan &
                                        pelayanan jasa hukum, berdiri dengan maksud untuk memberikan jasa hukum berupa
                                        tindakan pencegahan (preventif) atas potensi permasalahan hukum yang akan terjadi
                                        dikemudian
                                        hari, maupun tindakan penanganan (represif) atas permasalahan hukum yang sedang
                                        dihadapi
                                        oleh subyek hukum (perorangan maupun badan hukum). </h6>
                                    <div class="post-classic-footer">
                                    
                                        <a class="button button-link" href="#">Read more</a>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </section>

                    <!-- Layanan-->
                    <section class="section parallax-container bg-accent-2 text-center"
                        data-parallax-img="<?= bloginfo('template_directory')?>/assets/images/parallax-1.jpg">
                        <div class="parallax-content">
                            <div class="section-md text-center">
                                <div class="container">
                                    <div class="row justify-content-md-center">
                                        <div class="col-md-7 col-xl-6 mb-5 text-center">
                                            <h3 class="heading-decorated">Kami Hadir untuk Anda</h3>
                                            <div class="slick-line mt-2" style="width: 70%;">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row row-50 offset-top-1 justify-content-center ">


                                        <div class="col-md-6 col-lg-4">
                                            <!-- Blurb tiny-->
                                            <article class="blurb-tiny blurb-tiny_centered">
                                                <div class="blurb-tiny__icon linear-icon-library2"></div>
                                                <h5 class="blurb-tiny__title">Litigasi / Non Litigasi</h5>
                                                <p>Kami Siap menangani permasalahan Litigasi maupun Non Litigasi yang mana
                                                    kedua
                                                    hal
                                                    tersebut adalah bagian
                                                    dari strategi penyelesaian
                                                    permasalahan hukum dengan menggunakan atau tanpa menggunakan mekanisme
                                                    sistem
                                                    peradilan (di luar / di Pengadilan).</p>
                                            </article>
                                        </div>
                                        <div class="col-md-6 col-lg-4">
                                            <!-- Blurb tiny-->
                                            <article class="blurb-tiny blurb-tiny_centered">
                                                <div class="blurb-tiny__icon linear-icon-balance"></div>
                                                <h5 class="blurb-tiny__title">Konsultasi & Pendampingan</h5>
                                                <p>Kami Siap memberikan langkah-langkah "solutif" mengenai strategi Hukum
                                                    dalam
                                                    memetakan / analisa peristiwa hukum secara normatif ataupun pendampingan
                                                    langsung dalam membela serta memperjuangkan segala hak-hak klien guna
                                                    penyelesaian permasalahan hukum.</p>
                                            </article>
                                        </div>
                                        <div class="col-md-6 col-lg-4">
                                            <!-- Blurb tiny-->
                                            <article class="blurb-tiny blurb-tiny_centered">
                                                <!-- <div class="blurb-tiny__icon fa fa-handshake-o fa-3x"></div> -->
                                                <div class="blurb-tiny__icon linear-icon-license2"></div>
                                                <h5 class="blurb-tiny__title">Perizinian</h5>
                                                <p>Kami Siap membantu Anda dalan Pendirian Badan Usaha maupun Badan Hukum
                                                    seperti
                                                    Persekutuan Perdata (Maatshap), Persekutuan Komanditer (CV), Persekutuan
                                                    Firma,
                                                    Perseroan Terbatas (PT), Yayasan dan bentuk-bentuk badan hukum lainnya.
                                                </p>
                                            </article>
                                        </div>


                                        <div class="col-xl-8">

                                            <a class="button button-gray-light-outline" href="#">Ruang
                                                Lingkup praktik</a>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>




                    <!-- Blog & Galery-->
                    <section class="section-lg bg-default text-center">
                        <div class="container">
                            <h3 class="heading-decorated">Blog & Gallery</h3>
                            <div class="row row-50">

                                <div class="col-md-6 col-lg-4">
                                    <!-- Post classic-->
                                    <article class="post-classic post-minimal">
                                        <img src="<?= bloginfo('template_directory')?>/assets/images/post-classic-3-418x315.jpg" alt="" width="418"
                                            height="315">
                                        <div class="post-classic-title">
                                            <h5><a href="#">Pasal 378 KUHP tentang Penipuan</a></h5>
                                        </div>
                                        <div class="post-meta">
                                            <div class="group"><a href="standard-post.html">
                                                    <time datetime="2019">Nov.22, 2019</time></a><a class="meta-author"
                                                    href="standard-post.html">by Admin </a></div>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-md-6 col-lg-8">
                                    <!-- Post slider-->
                                    <article class="post-slider post-minimal">
                                        <!-- Owl Carousel-->
                                        <div class="owl-carousel carousel-post-gallery carousel-blog-post-minimal"
                                            data-autoplay="true" data-items="1" data-stage-padding="0" data-loop="true"
                                            data-margin="0" data-mouse-drag="false" data-nav="true" data-dots="true"
                                            data-lightgallery="group">
                                            <div class="item">
                                                <a class="img-thumbnail-variant-1"
                                                    href="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_1-1200x850.jpeg"
                                                    data-lightgallery="item">
                                                    <figure><img src="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_1-1200x850.jpeg" alt=""
                                                            width="886" height="668" />
                                                    </figure>
                                                    <div class="caption"><span
                                                            class="icon icon-lg linear-icon-magnifier"></span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="item"><a class="img-thumbnail-variant-1"
                                                    href="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_2_181053-1024x768.jpeg"
                                                    data-lightgallery="item">
                                                    <figure><img src="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_2_181053-1024x768.jpeg"
                                                            alt="" width="886" height="668" />
                                                    </figure>
                                                    <div class="caption"><span
                                                            class="icon icon-lg linear-icon-magnifier"></span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="item"><a class="img-thumbnail-variant-1"
                                                    href="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_3-170830-1024x576.jpeg"
                                                    data-lightgallery="item">
                                                    <figure><img src="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_3-170830-1024x576.jpeg"
                                                            alt="" width="886" height="668" />
                                                    </figure>
                                                    <div class="caption"><span
                                                            class="icon icon-lg linear-icon-magnifier"></span>
                                                    </div>
                                                </a>
                                            </div>

                                            <div class="item"><a class="img-thumbnail-variant-1"
                                                    href="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_4_161844-1536x864.jpeg"
                                                    data-lightgallery="item">
                                                    <figure><img src="<?= bloginfo('template_directory')?>/assets/images/gallery/IMG_4_161844-1536x864.jpeg"
                                                            alt="" width="886" height="668" />
                                                    </figure>
                                                    <div class="caption"><span
                                                            class="icon icon-lg linear-icon-magnifier"></span>
                                                    </div>
                                                </a>
                                            </div>

                                        </div>
                                        <div class="post-classic-title">
                                            <h5><a href="gallery-post.html">Angker Lawyers</a></h5>
                                        </div>
                                        <div class="post-meta">
                                            <div class="group">
                                                <a href="gallery-post.html">
                                                    <time datetime="2019">Nov.22, 2019</time>

                                                </a>
                                                <a class="meta-author" href="gallery-post.html">by Adam Smith</a>
                                            </div>
                                        </div>
                                    </article>
                                </div>



                            </div>
                        </div>
                    </section>



            </section>
            <!-- akhir Beranda -->
            <!-- ======================================================== -->


            <section id="tentang" class="wrapper__page">
                <!-- Company profile-->
                <section class="section-lg bg-default">
                    <div class="container">
                        <!-- Profile Corporate-->
                        <article class="profile-corporate">
                            <img class="profile-corporate__image" style="width: 270px !important"
                                src="<?= bloginfo('template_directory')?>/assets/images/logo/logo-270x270-mirror.png" alt="" />
                            <h2 class="heading-decorated heading-decorated_center profile-corporate__title">ANGKER
                                LAWYERS</h2>
                            <div class="slick-line" style="margin-bottom: 10px;  width: 50%;">
                            </div>
                            <h4 class="profile-corporate__subtitle">Advokat dan Konsultan Hukum
                            </h4>
                            <div class="profile-corporate__caption">
                                <h6 class="first-letter">Kantor Hukum “ANGKER LAWYERS”
                                    merupakan firma hukum yang terdiri dari para praktisi hukum,
                                    Advokat dan Konsultan Hukum yang tergabung dalam PERADI (Perhimpunan Advokat
                                    Indonesia)
                                    dengan kredibilitas / pengalaman mempuni
                                    dalam bidang penanganan &
                                    pelayanan jasa hukum, berdiri dengan maksud untuk memberikan jasa hukum berupa
                                    tindakan pencegahan (preventif) atas potensi permasalahan hukum yang akan terjadi
                                    dikemudian
                                    hari, maupun tindakan penanganan (represif) atas permasalahan hukum yang sedang
                                    dihadapi
                                    oleh subyek hukum (perorangan maupun badan hukum).
                                    <br>

                                    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kantor Hukum “ANGKER LAWYERS” berdasarkan Akta
                                        Pendirian
                                        Nomor 73
                                        pada Notaris
                                        Junjung
                                        Handoko Limantoro, S.H., adalah Kantor Hukum yang memberikan pelayanan jasa
                                        hukum bagi
                                        perorangan (person) maupun perusahaan-perusahaan lokal (Domestic Corporates),
                                        dan juga
                                        Pemerintahan baik secara litigasi maupun non litigasi, antara lain:

                                        <!-- Unordered list-->
                                        <section class="section-sm pb-4 pt-4">

                                            <ul class="list-ordered">
                                                <li> <b>Perkara Pidana
                                                        Umum &
                                                        Pidana Khusus :</b>&nbsp;Korupsi, penyalahgunaan Narkoba, sengketa
                                                    rumah
                                                    tangga
                                                    (Kekerasan Dalam
                                                    Rumah
                                                    Tangga) dan tindak pidana lainnya yang diatur oleh KUHP;
                                                </li>
                                                <li> <b> Perkara Perdata :</b>&nbsp;Perbankan,
                                                    sengketa perusahaan, sengketa Pilkada, Perselisihan Hubungan
                                                    Industrial /
                                                    ketenagakerjaan,
                                                    penanganan kredit macet, eksekusi hak tanggungan dan fiducia,
                                                    merger, akuisi
                                                    &
                                                    konsolidasi
                                                    perusahaan, klaim asuransi, HAKI, perceraian, dan adopsi anak, serta
                                                    pemberian legal
                                                    audit,
                                                    legal opinion, legal drafting, contract drafting, nasehat hukum,
                                                    konsultasi
                                                    hukum,
                                                    pemilu,
                                                    pembuatan perjanjian/kontrak, dan sebagainya;
                                                </li>
                                                <li>
                                                    <b> Hukum Pemerintahan Daerah :</b> &nbsp;Legal
                                                    Opini/Pendapat Hukum terkait kebijakan pelayanan publik oleh
                                                    Pemerintahan
                                                    Daerah, Legal
                                                    Drafting terkait kebijakan-kebijakan yang akan dikeluarkan oleh
                                                    Pemerintah
                                                    Daerah baik
                                                    peraturan daerah maupun Keputusan Bupati/Walikota, serta
                                                    pendampingan hukum
                                                    atas
                                                    permasalahan/sengketa hukum yang terkait dengan Pemerintah Daerah
                                                    baik
                                                    permasalahan
                                                    hukum
                                                    perdata, pidana, maupun tata usaha negara. </li>
                                            </ul>
                                        </section>

                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kantor Hukum “ANGKER LAWYERS”, mempunyai wilayah
                                        kerja yang mencakup 
                                        seluruh Indonesia.

                                        Sudah banyak perkara yang ditangani baik litigasi maupun
                                        non-litigasi di Kantor kami. Perkembangan yang begitu cepat ini tak lain berkat
                                        promosi
                                        dari
                                        klien-klien maupun mantan klien kami yang merasa puas atas kinerja kami selaku
                                        profesional
                                        di bidang hukum, sehingga mereka tak segan-segan mempromosikan kantor kami
                                        kepada
                                        kerabat
                                        dan rekan-rekan bisnisnya untuk menggunakan jasa hukum dari kantor kami.
                                    </p>
                                </h6>

                            </div>
                        </article>
                    </div>
                </section>

            </section>
            <!-- ======================================================== -->


            <section id="ruang" class="wrapper__page">


                <section class="bg-accent-2">
                    <section class="section parallax-container" data-parallax-img="<?= bloginfo('template_directory')?>/assets/images/parallax-3.jpg">
                        <div class="parallax-content parallax-header">
                            <div class="parallax-header__inner">
                                <div class="parallax-header__content">
                                    <div class="container">
                                        <div class="row justify-content-md-center">
                                            <div class="col-md-10 col-xl-8">
                                                <h3 class="heading-decorated heading-decorated_center mt-5">Ruang
                                                    Lingkup Praktik</h3>
                                                <div class="slick-line" style="margin-bottom: 10px;  width: 60%;"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                </section>


                <section class="section-md bg-default">
                    <div class="container">
                        <!-- Bootstrap tabs-->
                        <div class="tabs-custom tabs-horizontal " id="tabs-1">
                            <!-- Nav tabs-->
                            <ul class="nav nav-custom nav-custom-tabs ">
                                <li>
                                    <a class="nav-link active" href="#tabs-1-1" data-toggle="tab">
                                        <b>Litigasi</b>
                                    </a>
                                </li>
                                <li>
                                    <a class="nav-link" href="#tabs-1-2" data-toggle="tab">
                                        <b>Non Litigasi</b>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content text-left">
                            <!-- Isi Tab 1 -->

                            <div class="tab-pane fade show active" id="tabs-1-1">
                                <h5>Litigasi</h5>
                                <!-- <h6>Pendampingan Litigasi merupakan bagian dari strategi hukum yang diberikan oleh Advokat /
                                                    Pengacara kepada klien dalam penyelesaian permasalahan hukum dengan menggunakan mekanisme
                                                    sistem peradilan (kepolisian, kejaksaan dan di dalam peradilan mulai dari tingkat Pengadilan
                                                    Negeri sampai Mahkamah Agung).</h6> -->
                                <p>Advokat / Pengacara di kantor kami dapat mewakili kepentingan hukum para klien di
                                    dalam
                                    proses peradilan maupun pra-peradilan (penyidik Kepolisian maupun Kejaksaan dalam
                                    perkara
                                    pidana) dengan ruang lingkup sebagai berikut:</p>

                                <!-- Accordion  -->
                                <div class="container pl-0">
                                    <!-- Accordion -->
                                    <div id="accordion" role="tablist">
                                        <!-- Bootstrap card 1-->
                                        <div class="card card-custom card-classic pt-1 pb-3">

                                            <div class="card-custom-heading" id="accordionHeading1" role="tab">
                                                <h5 class="card-custom-title">
                                                    <a class="" role="button" data-toggle="collapse"
                                                        data-parent="#accordion" href="#accordionCollapse1"
                                                        aria-controls="accordionCollapse1">
                                                        <h6>PERDATA</h6>
                                                    </a>
                                                </h5>
                                            </div>

                                            <div class="card-custom-collapse collapse show" id="accordionCollapse1"
                                                role="tabpanel" aria-labelledby="accordionHeading1">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <!-- <h5>Details</h5> -->
                                                        <ul class="list-marked ">
                                                            <li>Mengajukan Gugatan Perdata;</li>
                                                            <li>Melakukan upaya hukum (verzet, banding, kasasi sampai
                                                                dengan
                                                                Peninjauan Kembali);</li>
                                                            <li>Clean Style. Cons and Pros.</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Bootstrap card 2-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="accordionHeading2" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion"
                                                        href="#accordionCollapse2" aria-controls="accordionCollapse2">
                                                        <h6>PIDANA UMUM & PIDANA KHUSUS</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="accordionCollapse2"
                                                role="tabpanel" aria-labelledby="accordionHeading2">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Mendampingi serta melindungi kepentingan hukum klien
                                                                dalam semua
                                                                proses perkara pidana baik ditingkat penyidik sampai
                                                                dengan di
                                                                Pengadilan;</li>
                                                            <li>Melakukan upaya hukum (banding, kasasi, sampai dengan
                                                                Peninjauan
                                                                Kembali);</li>
                                                            <li>Mengajukan Pra-Peradilan;</li>
                                                            <li>Mengajukan Permohonan Penangguhan Penahanan.</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Bootstrap card 3-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="accordionHeading3" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion"
                                                        href="#accordionCollapse3" aria-controls="accordionCollapse3">
                                                        <h6>SENGKETA TATA USAHA NEGARA (TUN)</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="accordionCollapse3"
                                                role="tabpanel" aria-labelledby="accordionHeading3">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Mengajukan gugatan sengketa TUN ke Pengadilan TUN;</li>
                                                            <li>Melakukan upaya hukum (proses dismissal, banding, dan
                                                                kasasi);
                                                            </li>
                                                            <li>Pada intinya menyelesaikan semua permasalahan yang
                                                                timbul dalam
                                                                sengketa TUN.</li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Bootstrap card 4-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="accordionHeading4" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion"
                                                        href="#accordionCollapse4" aria-controls="accordionCollapse4">
                                                        <h6>SENGKETA MEREK</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="accordionCollapse4"
                                                role="tabpanel" aria-labelledby="accordionHeading4">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Mengajukan gugatan ke Pengadilan Niaga;</li>
                                                            <li>Melakukan upaya hukum;</li>
                                                            <li>Menyelesaikan semua sengketa merek yang timbul dalam
                                                                transaksi
                                                                perdagangan.</li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Bootstrap card 5-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="accordionHeading5" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion"
                                                        href="#accordionCollapse5" aria-controls="accordionCollapse5">
                                                        <h6>SENGKETA PAJAK</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="accordionCollapse5"
                                                role="tabpanel" aria-labelledby="accordionHeading5">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Mengajukan keberatan-keberatan atas pajak yang
                                                                dibebankan kepada
                                                                Pengadilan Pajak;</li>
                                                            <li>Menyelesaikan semua permasalahan yang timbul dalam
                                                                sengketa
                                                                pajak.</li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Bootstrap card 6-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="accordionHeading6" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion"
                                                        href="#accordionCollapse6" aria-controls="accordionCollapse6">
                                                        <h6>PERKARA PERDATA AGAMA</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="accordionCollapse6"
                                                role="tabpanel" aria-labelledby="accordionHeading6">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Mengajukan permohonan talak atau gugatan cerai ke
                                                                Pengadilan
                                                                Agama;</li>
                                                            <li>Mengajukan permohonan penetapan waris;</li>
                                                            <li>Mengajukan permohonan hak asuh anak;</li>
                                                            <li>Mengajukan permohonan harta bersama (gono gini);</li>
                                                            <li>Melakukan upaya hukum (verzet, banding, kasasi).</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <!-- End Tablist 1 -->
                                </div>
                                <!-- End Container 1 -->

                            </div>

                            <!-- Isi Tab 1 End-->

                            <!-- ======================================================== -->
                            <!-- Isi Tab 2 -->
                            <div class="tab-pane fade" id="tabs-1-2">
                                <!-- <h5>Non Litigasi</h5> -->
                                <!-- <p>Welcome to our wonderful world. We sincerely hope that each and every user entering
                                    our
                                    website will find exactly what he/she is looking for. With advanced features of
                                    activating
                                    account and new login widgets, you will definitely have a great experience of using
                                    our web
                                    page. It will tell you lots of interesting things about our company, its products
                                    and
                                    services, highly professional staff and happy customers.</p> -->

                                <!-- Accordion  -->
                                <div class="container pl-0">
                                    <!-- Accordion -->
                                    <div id="accordion2" role="tablist">

                                        <!-- Non Litigasi card 1-->
                                        <div class="card card-custom card-classic pt-1 pb-3">

                                            <div class="card-custom-heading" id="HeadingNonLitigasi1" role="tab">
                                                <h5 class="card-custom-title">
                                                    <a class="" role="button" data-toggle="collapse"
                                                        data-parent="#accordion2" href="#CollapseNonLitigasi1"
                                                        aria-controls="CollapseNonLitigasi1">
                                                        <h6>HUKUM PERDATA DAN HUKUM BISNIS</h6>
                                                    </a>
                                                </h5>
                                            </div>

                                            <div class="card-custom-collapse collapse show" id="CollapseNonLitigasi1"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi1">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <!-- <h5>Details</h5> -->
                                                        <ul class="bold list-ordered ">
                                                            <li><b>Hukum Perusahaan</b>
                                                                <p>Pendirian Badan Usaha maupun Badan Hukum seperti
                                                                    Persekutuan
                                                                    Perdata (Maatshap), Persekutuan Komanditer (CV),
                                                                    Persekutuan
                                                                    Firma, Perseroan Terbatas (PT), Yayasan dan
                                                                    bentuk-bentuk
                                                                    badan
                                                                    hukum lainnya.</p>
                                                                <div class="container pt-0 mt-0">
                                                                    <ul class="list-marked">
                                                                        <li>Penggabungan Usaha Perseroan Terbatas
                                                                            (Merger)</li>
                                                                        <li>Akuisisi</li>
                                                                        <li>Pemisahan Aktiva / Pasiva (Spin off)</li>
                                                                        <li>Kepailitan</li>
                                                                        <li>Likuidasi</li>
                                                                        <li>Pengambil Alihan (Take Over)</li>

                                                                    </ul>
                                                                </div>
                                                                <p>Menyelesaikan konflik yang timbul dalam kegiatan
                                                                    transaksi
                                                                    ekonomi yang dilakukan oleh perusahaan melalui
                                                                    Negoisasi
                                                                    dan
                                                                    Mediasi.</p>
                                                            </li>


                                                            <li>Hukum Penanaman Modal / Investasi dan Hukum Pasar Modal
                                                                <p>Memberikan pelayanan mengenai prosedur Penanaman
                                                                    Modal di
                                                                    Indonesia baik modal asing (PMA) maupun modal dalam
                                                                    negeri
                                                                    (PMDN). Mengurus izin-izin Penanaman Modal di
                                                                    Indonesia,
                                                                    Melakukan Legal Due Diligence (LDD) dan membuat
                                                                    perjanjian
                                                                    patungan (Joint Venture Agreement), memberikan legal
                                                                    opinion
                                                                    berdasarkan legal audit bagi perusahaan yang akan
                                                                    melakukan
                                                                    emisi efek di pasar perdana maupun aktivitas lainnya
                                                                    di
                                                                    pasar modal.</p>
                                                            </li>
                                                            <li>Hak Atas Kekayaan Intelektual (Intellectual Property
                                                                Rights)

                                                                <p>Meliputi Pendaftaran hak merek, paten, dan hak cipta,
                                                                    pemberian lisensi serta aspek-aspek hukum yang
                                                                    mengikutinya,
                                                                    pencegahan sengketa serta tindakan-tindakan hukum
                                                                    preventif
                                                                    lainnya.</p>
                                                            </li>
                                                            <li>Franchise, Leasing, Keagenan, Perwakilan dan Kantor
                                                                Cabang
                                                                <p>Meliputi pembuatan dan pemerikasaan perjanjian serta
                                                                    pengurusan izin franchise dan leasing. Pengurusan
                                                                    penunjukan
                                                                    pembentukan keagenan atau perwakilan maupun kantor
                                                                    cabang.
                                                                </p>
                                                            </li>
                                                            <li>Hukum Perbankan
                                                                <p>Pendirian Bank Campuran, Pembuatan dan Pemeriksaan
                                                                    Perjanjian
                                                                    Anak Piutang, Pembuatan dan Pemeriksaan Perjanjian
                                                                    Kredit,
                                                                    Penanganan dan Penanggulangan Kredit Macet,
                                                                    Menangani serta
                                                                    memberikan legal opinion terhadap debitur yang
                                                                    beritikad
                                                                    tidak baik serta permasalahan lainnya dibidang
                                                                    perbankan
                                                                    sampai dengan di pengadilan.
                                                                </p>
                                                                <p>
                                                                    Menangani serta menyelesaikan proses eksekusi atas
                                                                    hak
                                                                    jaminan atau hak tanggungan sampai dengan proses
                                                                    lelang.
                                                                </p>

                                                            </li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Non Litigasi card 2-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="HeadingNonLitigasi2" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion2"
                                                        href="#CollapseNonLitigasi2"
                                                        aria-controls="CollapseNonLitigasi2">
                                                        <h6>HUKUM KESEHATAN</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="CollapseNonLitigasi2"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi2">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Penanganan Perkara Malpraktek Kedokteran;</li>
                                                            <li>Penanganan masalah hukum mengenai Rumah Sakit;</li>
                                                            <li>Penanganan masalah hukum mengenai Perawat;</li>
                                                            <li>Kode Etik Kedokteran.</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Non Litigasi card 3-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="HeadingNonLitigasi3" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion2"
                                                        href="#CollapseNonLitigasi3"
                                                        aria-controls="CollapseNonLitigasi3">
                                                        <h6>HUKUM AGRARIA</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="CollapseNonLitigasi3"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi3">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Sengketa tanah;</li>
                                                            <li>Pembebasan hak atas tanah;</li>
                                                            <li>Pensertifikatan tanah;</li>
                                                            <li>Pendaftaran Hak Tanggungan;</li>
                                                            <li>Perpanjangan HGB, HGU Hak Pakai, dll..</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Non Litigasi card 4-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="HeadingNonLitigasi4" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion2"
                                                        href="#CollapseNonLitigasi4"
                                                        aria-controls="CollapseNonLitigasi4">
                                                        <h6>HUKUM KETENAGAKERJAAN</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="CollapseNonLitigasi4"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi4">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Pembuatan dan Pemerikaan Perjanjian Kerja;</li>
                                                            <li>Pembuatan dan Pemeriksaan Peraturan Perusahaan dan
                                                                Perjanjian
                                                                Kerja Bersama;</li>
                                                            <li>Pemutusan Hubungan Kerja serta penyelesaian perselisihan
                                                                yang
                                                                timbul dalam hubungan industrial.</li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Non Litigasi card 5-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="HeadingNonLitigasi5" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion2"
                                                        href="#CollapseNonLitigasi5"
                                                        aria-controls="CollapseNonLitigasi5">
                                                        <h6>HUKUM PUBLIK</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="CollapseNonLitigasi5"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi5">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Hukum Pidana Umum & Pidana Khusus;
                                                                <p>
                                                                    Memberikan legal opinion atas segala perkara-perkara
                                                                    pidana
                                                                    baik ditingkat penyelidikan, penyidikan tingkat
                                                                    kepolisian
                                                                    maupun penuntutan tingkat kejaksaan sampai dengan
                                                                    pemeriksaan di pengadilan.
                                                                </p>
                                                            </li>
                                                            <li>Hukum Tata Usaha Negara;
                                                                <p>
                                                                    Memberikan legal opinion atas segala keputusan dari
                                                                    pejabat
                                                                    tata usaha negara yang secara hukum dianggap oleh
                                                                    klien
                                                                    merugikan.
                                                                </p>
                                                            </li>
                                                            <li>Hukum Keluarga (Baik berdasarkan BW maupun Hukum Islam).
                                                                <p>
                                                                    Memberikan Jasa Konsultasi tentang sengketa
                                                                    perkawinan,
                                                                    perceraian, perwalian atas anak dan pembagian atas
                                                                    harta
                                                                    perkawinan (gono gini), pembagian warisan, hibah dan
                                                                    wasiat.
                                                                </p>
                                                            </li>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <!-- Non Litigasi card 6-->
                                        <div class="card card-custom card-classic pt-3 pb-3">
                                            <div class="card-custom-heading" id="HeadingNonLitigasi6" role="tab">
                                                <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                        data-toggle="collapse" data-parent="#accordion2"
                                                        href="#CollapseNonLitigasi6"
                                                        aria-controls="CollapseNonLitigasi6">
                                                        <h6>HUKUM PEMERINTAHAN DAERAH</h6>
                                                    </a>
                                                </h5>
                                            </div>
                                            <div class="card-custom-collapse collapse" id="CollapseNonLitigasi6"
                                                role="tabpanel" aria-labelledby="HeadingNonLitigasi6">
                                                <div class="card-custom-body pt-3">

                                                    <div class="container pl-5">

                                                        <ul class="list-marked ">
                                                            <li>Memberikan pendapat hukum (Legal Opini) terkait
                                                                permasalahan
                                                                hukum yang sedang dihadapi oleh Pemerintah Daerah, serta
                                                                permasalahan / sengketa yang berpotensi timbul dimasa
                                                                mendatang.
                                                            </li>
                                                            <li>Menyusun draft peraturan / kebijakan yang akan
                                                                dikeluarkan
                                                                Pemerintah Daerah, baik draft Peraturan Bupati /
                                                                Walikota,
                                                                Keputusan Bupati / Walikota, maupun peraturan /
                                                                kebijakan lain.
                                                            </li>
                                                            <li>Mengulas (Legal Review) terhadap peraturan / kebijakan
                                                                yang
                                                                telah dikeluarkan oleh Pemerintah Daerah demi memberikan
                                                                pendapat hukum (Legal Opini) maupun nasihat hukum (Legal
                                                                Advice).</li>
                                                            <li>Melakukan pendampingan hukum terhadap Pemerintah Daerah
                                                                dalam
                                                                menangani permasalahan / sengketa hukum yang sedang
                                                                dihadapi,
                                                                baik permasalahan hukum perdata, pidana maupun sengketa
                                                                tata
                                                                usaha negara.</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                    </div>

                                    <!-- End Tablist 1 -->
                                </div>
                                <!-- End Container 1 -->



                            </div>
                            <!-- Isi Tab 2 End-->

                        </div>
                    </div>
                </section>

            </section>
            <!-- ======================================================== -->




            <section id="layanan" class="wrapper__page">


                <section class="bg-accent-2">
                    <section class="section parallax-container" data-parallax-img="<?= bloginfo('template_directory')?>/assets/images/parallax-6.jpg">
                        <div class="parallax-content parallax-header">
                            <div class="parallax-header__inner">
                                <div class="parallax-header__content">
                                    <div class="container">
                                        <div class="row justify-content-md-center">
                                            <div class="col-md-10 col-xl-8">
                                                <h2 class="heading-decorated heading-decorated_center mt-5">Layanan Kami
                                                </h2>
                                                <div class="slick-line" style="margin-bottom: 10px;  width: 50%;"></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                </section>


                <!-- Layanan  -->
                <section class="section-md bg-default">

                    <div class="container">
                        <h5>Litigasi</h5>

                        <p>Advokat / Pengacara di kantor kami dapat mewakili kepentingan hukum para klien di dalam
                            proses peradilan maupun pra-peradilan (penyidik Kepolisian maupun Kejaksaan dalam perkara
                            pidana) dengan ruang lingkup sebagai berikut:</p>


                        <!-- card Layanan 1 -->
                        <section class="section-sm bordered">
                            <!-- Blurb minimal-->
                            <article class="blurb">
                                <div class="unit flex-sm-row unit-spacing-md ">
                                    <div class="unit__left "><img class="img-circle"
                                            src="<?= bloginfo('template_directory')?>/assets/images/layanan/showimg-150x150.jpg" alt="" width="109"
                                            height="109">
                                    </div>
                                    <div class="unit__body">

                                        <div id="layanan" role="tablist">



                                            <!-- Bootstrap card 1-->
                                            <div class="card card-custom grey">
                                                <div class="card-custom-heading" id="HeadingLayanan1" role="tab">
                                                    <h5 class="card-custom-title"><a class="" role="button"
                                                            data-toggle="collapse" data-parent="#layanan"
                                                            href="#CollapseLayanan1"
                                                            aria-controls="CollapseLayanan1">LEGAL
                                                            DRAFTING</a>
                                                    </h5>
                                                </div>
                                                <div class="card-custom-collapse collapse show" id="CollapseLayanan1"
                                                    role="tabpanel" aria-labelledby="HeadingLayanan1">
                                                    <div class="card-custom-body">
                                                        <p>Kami dapat membantu klien dalam membuat dan menganalisa
                                                            surat-menyurat yang berhubungan dengan permasalahan
                                                            perusahaan, dan
                                                            surat-surat lain yang ditujukan kepada perusahaan maupun
                                                            perseorangan, seperti:</p>

                                                        <div class="container pl-1">

                                                            <ul class="list-marked ">
                                                                <li>Surat Peringatan / Teguran Hukum (Somasi);</li>
                                                                <li>Surat Klaim;</li>
                                                                <li>Surat Penagihan;</li>
                                                                <li>Peraturan Perusahaan;</li>
                                                                <li>dll...</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </article>
                        </section>

                        <!-- card Layanan 2 -->
                        <section class="section-sm bordered">
                            <!-- Blurb minimal-->
                            <article class="blurb">
                                <div class="unit flex-sm-row unit-spacing-md">
                                    <div class="unit__left"><img class="img-circle"
                                            src="<?= bloginfo('template_directory')?>/assets/images/layanan/GettyImages-513067681-58eae6513df78c5162a18185-150x150.jpg"
                                            alt="" width="109" height="109">
                                    </div>
                                    <div class="unit__body">

                                        <div id="layanan" role="tablist">



                                            <!-- Bootstrap card-->
                                            <div class="card card-custom grey">
                                                <div class="card-custom-heading" id="HeadingLayanan2" role="tab">
                                                    <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                            data-toggle="collapse" data-parent="#layanan"
                                                            href="#CollapseLayanan2"
                                                            aria-controls="CollapseLayanan2">LEGAL
                                                            ADVICE & LEGAL OPINION</a>
                                                    </h5>
                                                </div>
                                                <div class="card-custom-collapse collapse" id="CollapseLayanan2"
                                                    role="tabpanel" aria-labelledby="HeadingLayanan2">
                                                    <div class="card-custom-body">
                                                        <p>Kami sadar tidak ada satupun orang pribadi maupun subjek
                                                            hukum lain
                                                            seperti perusahaan yang tidak berhubungan dengan hukum dalam
                                                            aktifitasnya sehari-hari, oleh karenanya mau tidak mau kita
                                                            harus
                                                            menyesuaikan aktifitas kehidupan kita dengan hukum yang
                                                            sedang
                                                            berlaku.

                                                        </p>
                                                        <p>
                                                            Melihat hal tersebut Kantor Hukum “ANGKER LAWYERS” dapat
                                                            membantu
                                                            klien untuk menghadapi serta mengantisipasi permasalahan
                                                            hukum yang
                                                            akan terjadi yang berkaitan dengan aktifitasnya maupun
                                                            permasalahan
                                                            hukum yang terjadi.
                                                        </p>
                                                        <p>

                                                            Legal Opini dan Legal Advice ini dapat juga kami berikan
                                                            terhadap
                                                            klien yang sedang mengalami persoalan dan bermaksud
                                                            menyelesaikannya
                                                            sendiri, ataupun bagi sebuah perusahaan yang mengalami
                                                            persoalan
                                                            yang bermaksud memutuskan sesuatu demi perbaikan perusahaan.
                                                            Anda
                                                            ingin mendapatkan legal opinion atau legal advice untuk
                                                            kepentingan
                                                            Anda atau Perusahaan anda, silahkan menghubungi kami.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </article>
                        </section>


                        <!-- card Layanan 3 -->
                        <section class="section-sm bordered">
                            <!-- Blurb minimal-->
                            <article class="blurb">
                                <div class="unit flex-sm-row unit-spacing-md">
                                    <div class="unit__left"><img class="img-circle"
                                            src="<?= bloginfo('template_directory')?>/assets/images/layanan/Contracts-and-Gavel1-150x150.jpg" alt=""
                                            width="109" height="109">
                                    </div>
                                    <div class="unit__body">

                                        <div id="layanan" role="tablist">



                                            <!-- Bootstrap card-->
                                            <div class="card card-custom grey">
                                                <div class="card-custom-heading" id="HeadingLayanan3" role="tab">
                                                    <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                            data-toggle="collapse" data-parent="#layanan"
                                                            href="#CollapseLayanan3"
                                                            aria-controls="CollapseLayanan3">CONTRACT
                                                            DRAFTING</a>
                                                    </h5>
                                                </div>
                                                <div class="card-custom-collapse collapse" id="CollapseLayanan3"
                                                    role="tabpanel" aria-labelledby="HeadingLayanan3">
                                                    <div class="card-custom-body">
                                                        <p>
                                                            Dalam hal ini, kami selaku Advokat & Konsultan Hukum PERADI
                                                            dapat
                                                            menyusun draft perjanjian / kontrak (Contract Drafting)
                                                            untuk
                                                            kepentingan perusahaan dalam melakukan hubungan hukum dengan
                                                            pihak
                                                            lain, antara lain perjanjian jual-beli, perjanjian
                                                            sewa-menyewa,
                                                            perjanjian pinjam-meminjam, perjanjian hutang-piutang, dan
                                                            perjanjian lainnya.
                                                        </p>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </article>
                        </section>

                        <!-- card Layanan 4 -->
                        <section class="section-sm bordered">
                            <!-- Blurb minimal-->
                            <article class="blurb">
                                <div class="unit flex-sm-row unit-spacing-md">
                                    <div class="unit__left"><img class="img-circle"
                                            src="<?= bloginfo('template_directory')?>/assets/images/layanan/urus-izin-usaha-siup-150x150.jpg" alt=""
                                            width="109" height="109">
                                    </div>
                                    <div class="unit__body">

                                        <div id="layanan" role="tablist">



                                            <!-- Bootstrap card-->
                                            <div class="card card-custom grey">
                                                <div class="card-custom-heading" id="HeadingLayanan4" role="tab">
                                                    <h5 class="card-custom-title"><a class="collapsed" role="button"
                                                            data-toggle="collapse" data-parent="#layanan"
                                                            href="#CollapseLayanan4"
                                                            aria-controls="CollapseLayanan4">PENDAMPINGAN HUKUM</a>
                                                    </h5>
                                                </div>
                                                <div class="card-custom-collapse collapse" id="CollapseLayanan4"
                                                    role="tabpanel" aria-labelledby="HeadingLayanan4">
                                                    <div class="card-custom-body">
                                                        <p>
                                                            Pendampingan Hukum (Legal Assistance Services) adalah
                                                            merupakan
                                                            pelayanan dari Kantor Hukum “ANGKER LAWYERS” untuk
                                                            mendampingi
                                                            Perusahaan / Klien dalam berbagai aktifitasnya, seperti
                                                            dalam
                                                            Negosiasi Bisnis, Pembuatan MoU dan Kontrak Bisnis, dan
                                                            pembuatan
                                                            dokumen-dokumen hukum perusahaan, pengembangan dan perluasan
                                                            perusahaan, serta aktifitas-aktifitas perusahaan lainnya.

                                                        </p>
                                                        <p>
                                                            Pendampingan Hukum ini sangat penting karena bisa memberikan
                                                            berbagai saran dan masukan terhadap setiap aktifitas
                                                            perusahaan,
                                                            sehingga diharapkan sedini mungkin dapat mencegah ataupun
                                                            meminimalisir kerugian-kerugian yang tidak perlu.
                                                        </p>
                                                        <p>

                                                            Legal Assistance Services juga dapat diterapkan terhadap
                                                            pribadi
                                                            atau sebuah Keluarga yang mengutamakan keamanan status
                                                            sosial,
                                                            sehingga dalam aktifitas kehidupan sehari-harinya jangan
                                                            sampai
                                                            muncul permasalahan-permasalahan hukum yang menghancurkan
                                                            reputasi
                                                            keluarga besarnya di mata masyarakat. Pendampingan biasanya
                                                            terkait
                                                            dalam persoalan lingkup hukum pidana sebagai saksi, korban
                                                            ataupun
                                                            sebagai Tersangka.
                                                        </p>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </article>
                        </section>


                    </div>
                </section>


            </section>
            <!-- ======================================================== -->



            <section id="kontak" class="wrapper__page">

                <section class="section-lg bg-default">
                    <div class="container">
                        <div class="row row-50">



                            <div class="col-md-6 col-lg-7 col-xl-8">
                                <!-- <div class="map-canvas" id="map-canvas"></div> -->

                                <!-- Post video-->
                                <article class="post-video post-minimal post-video-wrap">
                                    <div class="map_info_wrap">

                                        <div class="map_info_card">

                                            <div class="info_place_desc">
                                                <div class="info_name">
                                                    ANGKER LAWYERS
                                                    <small>Advokat & Konsultan Hukum</small>
                                                </div>
                                                <div class="info_addres">Jl. Selorejo, Perumahan Griya Setaman Kav.
                                                    F, Kota Malang, Jawa
                                                    Timur.</div>

                                            </div>

                                            <div class="info_navigate">
                                                <a target="_blank" jstcache="52"
                                                    href="https://maps.google.com/maps?ll=-7.955486,112.635767&amp;z=13&amp;t=m&amp;hl=en-US&amp;gl=US&amp;mapclient=embed&amp;daddr=Jl.%20Selorejo%20Kota%20Malang%20Jawa%20Timur%2065141@-7.955485899999999,112.6357668"
                                                    class="navigate-link">
                                                    <div class="info_navigate_icon map_info_icon"></div>
                                                    <div jstcache="53" class="info_navigate_text">Directions</div>
                                                </a>


                                                <div class="info_tooltip_anchor">
                                                    <div class="info_tooltip_tip_outer"></div>
                                                    <div class="info_tooltip_tip_inner"></div>
                                                    <div class="info_tooltip_content">
                                                        <div jstcache="54">Get directions to this location on Google
                                                            Maps.</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div jstcache="41" class="review-box">
                                                <div jstcache="42" class="review-number" jsan="7.review-number">5.0
                                                </div>
                                                <div jstcache="43" jsinstance="0"
                                                    class="map_info_icon rating-star rating-full-star"
                                                    jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                <div jstcache="43" jsinstance="1"
                                                    class="map_info_icon rating-star rating-full-star"
                                                    jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                <div jstcache="43" jsinstance="2"
                                                    class="map_info_icon rating-star rating-full-star"
                                                    jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                <div jstcache="43" jsinstance="3"
                                                    class="map_info_icon rating-star rating-full-star"
                                                    jsan="7.icon,7.rating-star,7.rating-full-star"></div>
                                                <div jstcache="43" jsinstance="*4"
                                                    class="map_info_icon rating-star rating-full-star"
                                                    jsan="7.icon,7.rating-star,7.rating-full-star"></div> <a
                                                    target="_blank" jstcache="44"
                                                    href="https://www.google.com/search?safe=strict&ei=aT3tXbCZCM7gz7sPuJGe8AQ&q=Pengacara+di+malang+%7C+Angker+Lawyer%2C+jalan+Selorejo+Perumahan+Griya+Setaman+Kav+F+Kota+Malang+Jawa+Timur&oq=Pengacara+di+malang+%7C+Angker+Lawyer%2C+jalan+Selorejo+Perumahan+Griya+Setaman+Kav+F+Kota+Malang+Jawa+Timur&gs_l=psy-ab.3...14742.91164..93371...0.0..0.0.0.......26....1j2..gws-wiz.tlVrfl9tF-o&ved=0ahUKEwjw8bXy06bmAhVO8HMBHbiIB04Q4dUDCAs&uact=5"
                                                    jsaction="mouseup:placeCard.reviews" class="review-box-link"
                                                    jsan="7.review-box-link,8.href,0.target,22.jsaction">17
                                                    reviews</a>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="entry-video embed-responsive embed-responsive-16by9">
                                        <iframe width="886" height="320" id="gmap_canvas"
                                            src="https://maps.google.com/maps?q=Jalan%20Selorejo%2C%20Kota%20Malang%2C%20Jawa%20Timur&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                            frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
                                        </iframe>
                                        <!-- <iframe width="886" height="320" src="//www.youtube.com/embed/ccuQoF0vKYU"
                                            allowfullscreen=""></iframe> -->
                                    </div>

                                </article>
                            </div>

                            <div class="col-md-5 col-lg-4">
                                <h3 class="heading-decorated mt-4">Kontak Kami</h3>

                                <!-- <h5>Kantor</h5> -->
                                <ul class="list-ordered">
                                    <li>Jl. Selorejo, Perumahan Griya Setaman Kav. F, Kota Malang, Jawa
                                        Timur.
                                    </li>
                                    <li> Jl. Eastwood EW 6, No. 66, Citraland, Kota Surabaya, Jawa Timur.
                                    </li>
                                    <li>Jl. Mayor Abdullah, Kota Tual, Maluku Tenggara.</li>
                                </ul>


                                <div class="group mt-4 pages">
                                    <div class="icon-list-wrap icon icon-grey linear-icon-telephone">
                                        <a href="standard-post.html">
                                            081333936989 | 082238793851</a>
                                    </div>

                                    <div class="icon-list-wrap icon icon-grey linear-icon-envelope">
                                        <a href="standard-post.html">angkerlawyers@gmail.com</a>
                                    </div>

                                </div>



                                <dl class="list-terms-minimal font-secondary mt-4">
                                    <div class="icon-list-wrap icon icon-grey linear-icon-clock3">
                                        Jam Kerja :
                                    </div>
                                </dl>

                                <div class="container">

                                    <dl class="list-terms-minimal mt-2">
                                        <dt>Senin – Jum'at</dt>
                                        <dd>09.00-18.00 WIB.</dd>
                                    </dl>
                                    <dl class="list-terms-minimal">
                                        <dd>"Kecuali Hari Libur Nasional/Keagamaan"</dd>
                                        <!-- <dd>10am-4pm</dd> -->
                                    </dl>
                                </div>

                            </div>


                        </div>
                    </div>
                </section>


            </section>
            <!-- ======================================================== -->










        </section>
        <!-- end all Section -->


<?php get_footer() ?>